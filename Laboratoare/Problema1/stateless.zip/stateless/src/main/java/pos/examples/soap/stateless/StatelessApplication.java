package pos.examples.soap.stateless;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StatelessApplication {

	public static void main(String[] args) {
		SpringApplication.run(StatelessApplication.class, args);
	}

}
